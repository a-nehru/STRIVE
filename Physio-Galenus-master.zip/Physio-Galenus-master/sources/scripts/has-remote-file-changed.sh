#!/usr/bin/env bash

changed_files="$(git diff-tree -r --name-only --no-commit-id ORIG_HEAD HEAD)"
echo "$changed_files" | grep --quiet "$1"
