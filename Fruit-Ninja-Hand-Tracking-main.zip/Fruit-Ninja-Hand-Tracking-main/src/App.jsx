import { useEffect, useRef, useState } from 'react';
import creature1 from './assets/creature1.png';
import creature2 from './assets/creature2.png';
import creature3 from './assets/creature3.png';
import charminder from './assets/charminder.png';
import water from './assets/water.png';
import rhagar from './assets/rhagar.png';
import rocket from './assets/rocket.png';
import villain from './assets/villain.png';

import './App.css';

const TRAIL_LENGTH = 10
const MOTION_THRESHOLD = 25;
const SAMPLE_STEP = 3;
const SMOOTHING = 0.45;
const MAX_MISSES = 3;

const BASE_SPAWN_INTERVAL = 1500;
const MIN_SPAWN_INTERVAL = 500;
const BASE_GRAVITY = 0.22;
const MAX_GRAVITY = 0.4;
const BASE_LAUNCH_SPEED = 12;
const MAX_LAUNCH_SPEED = 16.5;
const DIFFICULTY_STEP = 5;
const MAX_DIFFICULTY_LEVEL = 6;

const GOOD_CREATURE_IMAGES = [creature1, creature2];
const BONUS_CREATURE_IMAGES = [rhagar, rocket, villain];
const BAD_CREATURE_IMAGES = [creature3, charminder, water];
const BAD_SPAWN_CHANCE = 0.35;
const BONUS_SPAWN_CHANCE = 0.35;
const AVATAR_BOX_SIZE = 150;

// Backend URL — change this if you deploy the backend somewhere else
const API_URL = 'http://localhost:5000';

function App() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const avatarCanvasRef = useRef(null);
  const objectsRef = useRef([]);
  const halvesRef = useRef([]);
  const particlesRef = useRef([]);
  const sparklesRef = useRef([]);
  const confettiRef = useRef([]);
  const flashRef = useRef(null);
  const shouldSpawnSparklesRef = useRef(false);
  const sparkleCounterRef = useRef(0);
  const celebrationCounterRef = useRef(0);
  const celebrationTriggeredRef = useRef(false);
  const punchRef = useRef(0);
  const lastSpawnRef = useRef(0);
  const trailRef = useRef([]);
  const scoreRef = useRef(0);
  const prevFrameRef = useRef(null);
  const smoothedPosRef = useRef(null);
  const missesRef = useRef(0);
  const gameOverRef = useRef(false);
  const nameSubmittedRef = useRef(false);
  const playerNameRef = useRef('');

  const [status, setStatus] = useState('Requesting camera access...');
  const [score, setScore] = useState(0);
  const [misses, setMisses] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [level, setLevel] = useState(1);
  const [playerName, setPlayerName] = useState('');
  const [nameSubmitted, setNameSubmitted] = useState(false);
  const [leaderboard, setLeaderboard] = useState([]);
  const [scoreSaved, setScoreSaved] = useState(false);
  const [isTopScore, setIsTopScore] = useState(false);
  const topScoreTriggeredRef = useRef(false);

  useEffect(() => {
    navigator.mediaDevices
      .getUserMedia({ video: true })
      .then((stream) => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setStatus('Camera ready — point a blue light at the screen');
        }
      })
      .catch((err) => {
        console.error('Camera error:', err);
        setStatus(
          `Camera failed: ${err.name}. Allow camera access via the address bar icon, then reload.`
        );
      });
  }, []);

  useEffect(() => {
    // Check if current score is a top score
    if (nameSubmitted && !gameOver && leaderboard.length > 0) {
      const isTop = leaderboard.some((entry) => scoreRef.current > entry.score);
      if (isTop && !topScoreTriggeredRef.current) {
        setIsTopScore(true);
        shouldSpawnSparklesRef.current = true;
        topScoreTriggeredRef.current = true;
      } else if (!isTop) {
        topScoreTriggeredRef.current = false;
      }
    }
  }, [leaderboard, nameSubmitted, gameOver]);

async function submitScore(finalScore) {
  try {
    const res = await fetch(`${API_URL}/api/scores`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: playerNameRef.current,
        score: finalScore,
      }),
    });

    if (!res.ok) {
      console.error('Score submission rejected:', await res.text());
      return;
    }

    setScoreSaved(true);
    await fetchLeaderboard();

  } catch (err) {
    console.error('Failed to submit score:', err);
  }
}

async function fetchLeaderboard() {
  try {
    const res = await fetch(`${API_URL}/api/scores/top`);
    const data = await res.json();
    setLeaderboard(data);
  } catch (err) {
    console.error('Failed to fetch leaderboard:', err);
  }
}

  useEffect(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    function resizeCanvas() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const motionCanvas = document.createElement('canvas');
    const MOTION_W = 160;
    const MOTION_H = 120;
    motionCanvas.width = MOTION_W;
    motionCanvas.height = MOTION_H;
    const motionCtx = motionCanvas.getContext('2d', { willReadFrequently: true });

    let animationId;

    function stripWhiteBackground(img) {
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = img.width || img.naturalWidth || 1;
      tempCanvas.height = img.height || img.naturalHeight || 1;
      const tempCtx = tempCanvas.getContext('2d');
      tempCtx.drawImage(img, 0, 0);

      const imageData = tempCtx.getImageData(0, 0, tempCanvas.width, tempCanvas.height);
      const data = imageData.data;

      const corners = [
        [0, 0],
        [tempCanvas.width - 1, 0],
        [0, tempCanvas.height - 1],
        [tempCanvas.width - 1, tempCanvas.height - 1],
      ];

      let bgR = 255;
      let bgG = 255;
      let bgB = 255;
      let sampleCount = 0;

      corners.forEach(([x, y]) => {
        const i = (y * tempCanvas.width + x) * 4;
        const a = data[i + 3];
        if (a > 0) {
          bgR += data[i];
          bgG += data[i + 1];
          bgB += data[i + 2];
          sampleCount += 1;
        }
      });

      if (sampleCount > 0) {
        bgR = bgR / (sampleCount + 1);
        bgG = bgG / (sampleCount + 1);
        bgB = bgB / (sampleCount + 1);
      }

      const tolerance = 45;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const a = data[i + 3];

        const closeToBackground =
          Math.abs(r - bgR) < tolerance &&
          Math.abs(g - bgG) < tolerance &&
          Math.abs(b - bgB) < tolerance;

        if (a === 0 || closeToBackground) {
          data[i + 3] = 0;
        }
      }

      tempCtx.putImageData(imageData, 0, 0);
      const cleaned = new Image();
      cleaned.src = tempCanvas.toDataURL('image/png');
      return cleaned;
    }

    function loadTransparentImage(src) {
      const img = new Image();
      img.onload = () => {
        const cleaned = stripWhiteBackground(img);
        img.onload = null;
        img.src = cleaned.src;
      };
      img.src = src;
      return img;
    }

    const loadedGoodImages = GOOD_CREATURE_IMAGES.map((src) => loadTransparentImage(src));
    const loadedBonusImages = BONUS_CREATURE_IMAGES.map((src) => loadTransparentImage(src));
    const loadedBadImages = BAD_CREATURE_IMAGES.map((src) => loadTransparentImage(src));

    function getDifficultyLevel() {
      return Math.min(
        Math.floor(scoreRef.current / DIFFICULTY_STEP),
        MAX_DIFFICULTY_LEVEL
      );
    }

    function getSpawnInterval() {
      const lvl = getDifficultyLevel();
      const t = lvl / MAX_DIFFICULTY_LEVEL;
      return BASE_SPAWN_INTERVAL - t * (BASE_SPAWN_INTERVAL - MIN_SPAWN_INTERVAL);
    }

    function getGravity() {
      const lvl = getDifficultyLevel();
      const t = lvl / MAX_DIFFICULTY_LEVEL;
      return BASE_GRAVITY + t * (MAX_GRAVITY - BASE_GRAVITY);
    }

    function getLaunchSpeed() {
      const lvl = getDifficultyLevel();
      const t = lvl / MAX_DIFFICULTY_LEVEL;
      return BASE_LAUNCH_SPEED + t * (MAX_LAUNCH_SPEED - BASE_LAUNCH_SPEED);
    }

function spawnObject() {
      const isBad = Math.random() < BAD_SPAWN_CHANCE;
      const isBonus = !isBad && Math.random() < BONUS_SPAWN_CHANCE;
      const launchSpeed = getLaunchSpeed();

      // Spawn from a safe in-screen range so objects stay visible and land inside the monitor.
      const marginX = 120;
      const startX = marginX + Math.random() * (canvas.width - marginX * 2);
      const startY = canvas.height + 30;

      // Randomize the launch direction: angle measured from straight up.
      // 0 = straight up, negative = leaning left, positive = leaning right.
      // Keeping it within roughly ±25 degrees to keep creatures more centered
      // and reachable for a significant time by hand.
      const maxLeanDegrees = 50;
      const leanDegrees = (Math.random() * 2 - 1) * maxLeanDegrees; // -50 to +50
      const leanRadians = (leanDegrees * Math.PI) / 180;

      // Convert angle + speed into vx/vy components.
      // "Straight up" in canvas terms is vy negative, vx zero.
      const speedVariance = launchSpeed + Math.random() * 3;
      const vx = Math.sin(leanRadians) * speedVariance;
      const vy = -Math.cos(leanRadians) * speedVariance;

      const goodPool = isBonus ? loadedBonusImages : loadedGoodImages;

      objectsRef.current.push({
        id: Date.now() + Math.random(),
        x: startX,
        y: startY,
        radius: 65,
        vy,
        vx,
        rotation: 0,
        rotSpeed: (Math.random() - 0.5) * 0.08,
        sliced: false,
        pastPeak: false,
        isBad,
        isBonus,
        imgIndex: isBad ? Math.floor(Math.random() * loadedBadImages.length) : Math.floor(Math.random() * goodPool.length),
        badImageIndex: isBad ? Math.floor(Math.random() * loadedBadImages.length) : 0,
      });
    }

    function spawnParticles(x, y, color) {
      for (let i = 0; i < 22; i += 1) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 3 + Math.random() * 6;
        particlesRef.current.push({
          x, y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 1,
          size: 2 + Math.random() * 3,
          color,
        });
      }
    }

    function spawnSparkles(x, y) {
      const colors = ['#FFD700', '#FFF44F', '#FFEB3B', '#FFC107'];
      for (let i = 0; i < 15; i += 1) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 2 + Math.random() * 5;
        sparklesRef.current.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 2,
          life: 1,
          size: 3 + Math.random() * 2,
          color: colors[Math.floor(Math.random() * colors.length)],
        });
      }
    }

    function spawnConfetti(x, y) {
      const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2'];
      for (let i = 0; i < 25; i += 1) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 4 + Math.random() * 8;
        confettiRef.current.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 3,
          life: 1,
          size: 4 + Math.random() * 4,
          color: colors[Math.floor(Math.random() * colors.length)],
          rotation: Math.random() * Math.PI * 2,
          rotSpeed: (Math.random() - 0.5) * 0.2,
        });
      }
    }

    function spawnHalves(obj, sliceAngle) {
      const img = obj.isBad
        ? loadedBadImages[obj.badImageIndex ?? obj.imgIndex]
        : (obj.isBonus ? loadedBonusImages[obj.imgIndex] : loadedGoodImages[obj.imgIndex]);
      const perp = sliceAngle + Math.PI / 2;
      const kick = 5;

      [-1, 1].forEach((side) => {
        halvesRef.current.push({
          img,
          x: obj.x,
          y: obj.y,
          radius: obj.radius,
          rotation: obj.rotation,
          rotSpeed: obj.rotSpeed + side * 0.15,
          vx: obj.vx + Math.cos(perp) * kick * side,
          vy: obj.vy + Math.sin(perp) * kick * side - 2,
          side,
          sliceAngle,
          life: 1,
        });
      });
    }

    function detectBlueLight() {
      motionCtx.save();
      motionCtx.scale(-1, 1);
      motionCtx.drawImage(video, -MOTION_W, 0, MOTION_W, MOTION_H);
      motionCtx.restore();

      const frame = motionCtx.getImageData(0, 0, MOTION_W, MOTION_H);
      const data = frame.data;

      let sumX = 0;
      let sumY = 0;
      let totalWeight = 0;

      for (let y = 0; y < MOTION_H; y += SAMPLE_STEP) {
        for (let x = 0; x < MOTION_W; x += SAMPLE_STEP) {
          const i = (y * MOTION_W + x) * 4;
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const brightness = (r + g + b) / 3;
          const blueBias = b - Math.max(r, g);

          // Detect a bright blue object rather than arbitrary hand motion.
          if (b > 80 && brightness > 35 && blueBias > 20 && b > r * 1.2 && b > g * 1.2) {
            const weight = b * 0.7 + brightness * 0.8 + Math.max(blueBias, 0);
            sumX += x * weight;
            sumY += y * weight;
            totalWeight += weight;
          }
        }
      }

      if (totalWeight < 350) return null;

      const scaleX = canvas.width / MOTION_W;
      const scaleY = canvas.height / MOTION_H;
      const rawX = (sumX / totalWeight) * scaleX;
      const rawY = (sumY / totalWeight) * scaleY;

      if (!smoothedPosRef.current) {
        smoothedPosRef.current = { x: rawX, y: rawY };
      } else {
        smoothedPosRef.current = {
          x: smoothedPosRef.current.x + (rawX - smoothedPosRef.current.x) * SMOOTHING,
          y: smoothedPosRef.current.y + (rawY - smoothedPosRef.current.y) * SMOOTHING,
        };
      }

      return { x: smoothedPosRef.current.x, y: smoothedPosRef.current.y };
    }

    function pointToSegmentDistance(px, py, x1, y1, x2, y2) {
      const dx = x2 - x1;
      const dy = y2 - y1;
      const lengthSq = dx * dx + dy * dy;
      let t = lengthSq === 0 ? 0 : ((px - x1) * dx + (py - y1) * dy) / lengthSq;
      t = Math.max(0, Math.min(1, t));
      return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
    }

    function checkCollisions() {
      const trail = trailRef.current;
      if (trail.length < 2) return;

      const p1 = trail[trail.length - 2];
      const p2 = trail[trail.length - 1];
      const speed = Math.hypot(p2.x - p1.x, p2.y - p1.y);
      if (speed < 4) return;

      const sliceAngle = Math.atan2(p2.y - p1.y, p2.x - p1.x);

      objectsRef.current.forEach((obj) => {
        if (obj.sliced) return;
        const dist = pointToSegmentDistance(obj.x, obj.y, p1.x, p1.y, p2.x, p2.y);
        if (dist < obj.radius) {
          obj.sliced = true;

          if (obj.isBad) {
            missesRef.current += 1;
            setMisses(missesRef.current);
            if (missesRef.current >= MAX_MISSES) {
              gameOverRef.current = true;
              setGameOver(true);
              submitScore(scoreRef.current);
            }
            spawnParticles(obj.x, obj.y, '#ff3b3b');
          } else {
            const scoreGain = obj.isBonus ? 2 : 1;
            scoreRef.current += scoreGain;
            setScore(scoreRef.current);
            setLevel(getDifficultyLevel() + 1);
            spawnParticles(obj.x, obj.y, obj.isBonus ? '#ffd166' : '#2ecc71');
          }

          spawnHalves(obj, sliceAngle);
          flashRef.current = { p1, p2, life: 1 };
          punchRef.current = 1;
        }
      });
    }

    function drawCreature(obj) {
      const img = obj.isBad
        ? loadedBadImages[obj.badImageIndex ?? obj.imgIndex]
        : (obj.isBonus ? loadedBonusImages[obj.imgIndex] : loadedGoodImages[obj.imgIndex]);
      if (!img.complete || img.naturalWidth === 0) return;

      const ringColor = obj.isBad ? '#ff3b3b' : (obj.isBonus ? '#ffd166' : '#2ecc71');

      ctx.save();
      ctx.translate(obj.x, obj.y);
      ctx.rotate(obj.rotation);

      ctx.beginPath();
      ctx.arc(0, 0, obj.radius * 1.08, 0, Math.PI * 2);
      ctx.lineWidth = 5;
      ctx.strokeStyle = ringColor;
      ctx.shadowColor = ringColor;
      ctx.shadowBlur = 12;
      ctx.stroke();
      ctx.shadowBlur = 0;

      const size = obj.radius * 2;
      ctx.drawImage(img, -size / 2, -size / 2, size, size);
      ctx.restore();
    }

    function drawHalves() {
      halvesRef.current.forEach((h) => {
        h.x += h.vx;
        h.y += h.vy;
        h.vy += 0.3;
        h.rotation += h.rotSpeed;
        h.life -= 0.018;

        if (!h.img.complete || h.img.naturalWidth === 0) return;

        const size = h.radius * 2;
        ctx.save();
        ctx.globalAlpha = Math.max(h.life, 0);
        ctx.translate(h.x, h.y);
        ctx.rotate(h.rotation);

        ctx.beginPath();
        const cutNormal = h.sliceAngle - h.rotation + Math.PI / 2;
        const cx = Math.cos(cutNormal) * size;
        const cy = Math.sin(cutNormal) * size;
        ctx.moveTo(0, 0);
        ctx.lineTo(cx * h.side, cy * h.side);
        ctx.lineTo(cx * h.side - cy * h.side * 2, cy * h.side + cx * h.side * 2);
        ctx.closePath();
        ctx.clip();

        ctx.drawImage(h.img, -size / 2, -size / 2, size, size);
        ctx.restore();
      });
      ctx.globalAlpha = 1;
      halvesRef.current = halvesRef.current.filter((h) => h.life > 0 && h.y < canvas.height + 200);
    }

    function drawParticles() {
      particlesRef.current.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.2;
        p.life -= 0.035;
        ctx.globalAlpha = Math.max(p.life, 0);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();
      });
      ctx.globalAlpha = 1;
      particlesRef.current = particlesRef.current.filter((p) => p.life > 0);
    }

    function drawSparkles() {
      sparklesRef.current.forEach((s) => {
        s.x += s.vx;
        s.y += s.vy;
        s.vy += 0.1;
        s.life -= 0.04;
        ctx.globalAlpha = Math.max(s.life, 0);
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
        ctx.fillStyle = s.color;
        ctx.shadowBlur = 15;
        ctx.shadowColor = s.color;
        ctx.fill();
        ctx.shadowBlur = 0;
      });
      ctx.globalAlpha = 1;
      sparklesRef.current = sparklesRef.current.filter((s) => s.life > 0);
    }

    function drawConfetti() {
      confettiRef.current.forEach((c) => {
        c.x += c.vx;
        c.y += c.vy;
        c.vy += 0.25;
        c.rotation += c.rotSpeed;
        c.life -= 0.02;
        ctx.globalAlpha = Math.max(c.life, 0);
        ctx.save();
        ctx.translate(c.x, c.y);
        ctx.rotate(c.rotation);
        ctx.fillStyle = c.color;
        ctx.fillRect(-c.size / 2, -c.size / 2, c.size, c.size);
        ctx.restore();
      });
      ctx.globalAlpha = 1;
      confettiRef.current = confettiRef.current.filter((c) => c.life > 0);
    }

    function drawFlash() {
      if (!flashRef.current) return;
      const f = flashRef.current;
      ctx.save();
      ctx.globalAlpha = Math.max(f.life, 0);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(f.p1.x, f.p1.y);
      ctx.lineTo(f.p2.x, f.p2.y);
      ctx.stroke();
      ctx.restore();
      f.life -= 0.15;
      if (f.life <= 0) flashRef.current = null;
    }

    function drawTrail() {
      const trail = trailRef.current;
      if (trail.length < 2) return;

      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      for (let i = 1; i < trail.length - 1; i += 1) {
        const p0 = trail[i - 1];
        const p1 = trail[i];
        const p2 = trail[i + 1];
        const midX = (p1.x + p2.x) / 2;
        const midY = (p1.y + p2.y) / 2;
        const alpha = (i / trail.length) * 0.35;

        ctx.beginPath();
        ctx.moveTo((p0.x + p1.x) / 2, (p0.y + p1.y) / 2);
        ctx.quadraticCurveTo(p1.x, p1.y, midX, midY);
        ctx.lineWidth = 10;
        ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.stroke();
      }

      for (let i = 1; i < trail.length - 1; i += 1) {
        const p0 = trail[i - 1];
        const p1 = trail[i];
        const p2 = trail[i + 1];
        const midX = (p1.x + p2.x) / 2;
        const midY = (p1.y + p2.y) / 2;
        const alpha = i / trail.length;

        ctx.beginPath();
        ctx.moveTo((p0.x + p1.x) / 2, (p0.y + p1.y) / 2);
        ctx.quadraticCurveTo(p1.x, p1.y, midX, midY);
        ctx.lineWidth = 1.5 + alpha * 2.5;
        ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.stroke();
      }
    }

    function drawAvatar() {
      const avatarCanvas = avatarCanvasRef.current;
      if (!avatarCanvas) return;
      const actx = avatarCanvas.getContext('2d');
      const W = AVATAR_BOX_SIZE;
      const H = AVATAR_BOX_SIZE;
      actx.clearRect(0, 0, W, H);

      const cx = W / 2;
      const cy = H / 2;

      actx.fillStyle = '#0d1b2a';
      actx.fillRect(0, 0, W, H);

      const pos = smoothedPosRef.current;
      const targetX = pos ? Math.min(Math.max(pos.x / (canvas.width || 1) * W, 18), W - 18) : cx;
      const targetY = pos ? Math.min(Math.max(pos.y / (canvas.height || 1) * H, 18), H - 18) : cy;

      actx.shadowColor = '#3bb4ff';
      actx.shadowBlur = 20;
      actx.fillStyle = '#4dd0ff';
      actx.beginPath();
      actx.arc(targetX, targetY, 18, 0, Math.PI * 2);
      actx.fill();

      actx.shadowBlur = 0;
      actx.strokeStyle = '#b7ecff';
      actx.lineWidth = 2;
      actx.beginPath();
      actx.arc(targetX, targetY, 26, 0, Math.PI * 2);
      actx.stroke();

      actx.fillStyle = '#1d3557';
      actx.fillRect(0, H - 24, W, 24);
    }

    function drawFrame(timestamp) {
      // Spawn sparkles for top score periodically
      if (isTopScore) {
        sparkleCounterRef.current += 1;
        if (sparkleCounterRef.current % 15 === 0) {
          spawnSparkles(canvas.width / 2, 80);
        }
      } else {
        sparkleCounterRef.current = 0;
      }

      // Spawn celebration confetti when game ends
      if (gameOverRef.current && !celebrationTriggeredRef.current) {
        for (let i = 0; i < 8; i += 1) {
          spawnConfetti(
            canvas.width / 2 + (Math.random() - 0.5) * 200,
            canvas.height / 3
          );
        }
        celebrationTriggeredRef.current = true;
      }

      // Continue spawning confetti during celebration
      if (gameOverRef.current) {
        celebrationCounterRef.current += 1;
        if (celebrationCounterRef.current % 12 === 0) {
          for (let i = 0; i < 3; i += 1) {
            spawnConfetti(
              canvas.width / 2 + (Math.random() - 0.5) * 250,
              canvas.height / 4 + (Math.random() - 0.5) * 50
            );
          }
        }
      } else {
        celebrationCounterRef.current = 0;
      }

      punchRef.current = Math.max(punchRef.current - 0.08, 0);
      const zoom = 1 + punchRef.current * 0.015;

      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.scale(zoom, zoom);
      ctx.translate(-canvas.width / 2, -canvas.height / 2);

      if (video && video.readyState === video.HAVE_ENOUGH_DATA) {
        ctx.save();
        ctx.scale(-1, 1);
        ctx.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
        ctx.restore();

        const motionPoint = detectBlueLight();
        if (motionPoint) {
          trailRef.current.push(motionPoint);
          if (trailRef.current.length > TRAIL_LENGTH) trailRef.current.shift();
        }
      } else {
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      if (!gameOverRef.current && nameSubmittedRef.current) {
        if (!lastSpawnRef.current) lastSpawnRef.current = timestamp;
        if (timestamp - lastSpawnRef.current > getSpawnInterval()) {
          spawnObject();
          lastSpawnRef.current = timestamp;
        }
        checkCollisions();
      }

      const gravity = getGravity();

      objectsRef.current.forEach((obj) => {
        obj.vy += gravity;
        obj.y += obj.vy;
        obj.x += obj.vx;

        const minX = 60;
        const maxX = canvas.width - 60;
        if (obj.x < minX || obj.x > maxX) {
          obj.x = Math.min(Math.max(obj.x, minX), maxX);
          obj.vx *= -0.35;
        }

      

        obj.rotation += obj.rotSpeed;
        if (obj.vy > 0) obj.pastPeak = true;
      });

      objectsRef.current.forEach((obj) => {
        if (!obj.sliced && obj.pastPeak && obj.y - obj.radius >= canvas.height) {
          if (!obj.isBad) {
            missesRef.current += 1;
            setMisses(missesRef.current);
            if (missesRef.current >= MAX_MISSES) {
              gameOverRef.current = true;
              setGameOver(true);
              submitScore(scoreRef.current);
            }
          }
        }
      });

      objectsRef.current = objectsRef.current.filter((obj) => {
        if (obj.sliced) return false;
        if (obj.pastPeak && obj.y - obj.radius >= canvas.height) return false;
        return true;
      });

      objectsRef.current.forEach((obj) => drawCreature(obj));
      drawHalves();
      drawParticles();
      drawSparkles();
      drawConfetti();
      drawTrail();
      drawFlash();

      if (gameOverRef.current) {
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 44px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Game Over', canvas.width / 2, canvas.height / 2 - 16);
        ctx.font = '22px Arial';
        ctx.fillText(`Final Score: ${scoreRef.current}`, canvas.width / 2, canvas.height / 2 + 26);
      }

      ctx.restore();

      drawAvatar();

      animationId = requestAnimationFrame(drawFrame);
    }

    animationId = requestAnimationFrame(drawFrame);
    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  function handleRestart() {
    setNameSubmitted(false);
    setPlayerName('');
    setScoreSaved(false);
    setIsTopScore(false);
    nameSubmittedRef.current = false;
    objectsRef.current = [];
    halvesRef.current = [];
    particlesRef.current = [];
    sparklesRef.current = [];
    confettiRef.current = [];
    flashRef.current = null;
    punchRef.current = 0;
    trailRef.current = [];
    smoothedPosRef.current = null;
    scoreRef.current = 0;
    missesRef.current = 0;
    gameOverRef.current = false;
    lastSpawnRef.current = 0;
    topScoreTriggeredRef.current = false;
    celebrationTriggeredRef.current = false;
    setScore(0);
    setMisses(0);
    setGameOver(false);
    setLevel(1);
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: '#000', overflow: 'hidden' }}>
      <video ref={videoRef} autoPlay playsInline style={{ display: 'none' }} />
      <canvas
        ref={canvasRef}
        style={{ position: 'fixed', top: 0, left: 0, display: 'block' }}
      />

      {status && (
        <p
          style={{
            position: 'fixed',
            top: '16px',
            left: '50%',
            transform: 'translateX(-50%)',
            color: '#fff',
            fontFamily: 'Arial, sans-serif',
            fontSize: '14px',
            fontWeight: 600,
            textShadow: '0 2px 6px rgba(0,0,0,0.8)',
            zIndex: 3,
          }}
        >
          {status}
        </p>
      )}

      <div
        style={{
          position: 'fixed',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          gap: '28px',
          color: '#fff',
          fontFamily: 'Arial, sans-serif',
          fontSize: '20px',
          fontWeight: 700,
          textShadow: '0 2px 6px rgba(0,0,0,0.85)',
          zIndex: 12,
        }}
      >
        <span>Score: {score}</span>
        <span>Level: {level}</span>
        <span>Lives: {MAX_MISSES - misses}/{MAX_MISSES}</span>
      </div>

      {nameSubmitted && !gameOver && (
        <div
          style={{
            position: 'fixed',
            top: '80px',
            left: '20px',
            color: '#fff',
            background: 'rgba(0,0,0,0.28)',
            border: '1px solid rgba(255,255,255,0.2)',
            borderRadius: '12px',
            padding: '14px 18px',
            textAlign: 'left',
            minWidth: '180px',
            fontFamily: 'Arial, sans-serif',
            zIndex: 12,
          }}
        >
          <p style={{ fontWeight: 700, margin: '0 0 8px', fontSize: '16px' }}>🏆 Leaderboard</p>
          {leaderboard.length > 0 ? (
            leaderboard.map((entry, i) => (
              <p key={i} style={{ margin: '4px 0', fontSize: '14px' }}>
                {i + 1}. {entry.name} — {entry.score}
              </p>
            ))
          ) : (
            <p style={{ margin: 0, fontSize: '14px' }}>No scores yet</p>
          )}
        </div>
      )}

      <canvas
        ref={avatarCanvasRef}
        width={AVATAR_BOX_SIZE}
        height={AVATAR_BOX_SIZE}
        style={{
          position: 'fixed',
          bottom: '30px',
          right: '30px',
          zIndex: 3,
        }}
      />

      {!nameSubmitted && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.75)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 5,
          }}
        >
          <p style={{ color: '#fff', fontSize: '20px', fontWeight: 700, marginBottom: '12px' }}>
            Enter your name to play
          </p>
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && playerName.trim()) {
                setNameSubmitted(true);
                nameSubmittedRef.current = true;
                playerNameRef.current = playerName.trim();
              }
            }}
            placeholder="Your name"
            style={{
              padding: '10px 16px',
              fontSize: '16px',
              borderRadius: '8px',
              border: 'none',
              marginBottom: '12px',
              width: '220px',
              textAlign: 'center',
            }}
          />
          <button
         onClick={() => {
              if (playerName.trim()) {
                setNameSubmitted(true);
                nameSubmittedRef.current = true;
                playerNameRef.current = playerName.trim();
              }
            }}
            style={{
              padding: '10px 26px',
              fontSize: '16px',
              fontWeight: 700,
              cursor: 'pointer',
              borderRadius: '999px',
              border: 'none',
              background: '#fff',
              color: '#1a1a1a',
            }}
          >
            Start Game
          </button>
        </div>
      )}

      {gameOver && (
        <div
          style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            display: 'flex',
            alignItems: 'center',
            gap: '38px',
            zIndex: 4,
            width: 'min(760px, 80vw)',
          }}
        >
          <div
            style={{
              flex: '0 0 auto',
              color: '#fff',
              background: 'rgba(0,0,0,0.28)',
              border: '1px solid rgba(255,255,255,0.2)',
              borderRadius: '12px',
              padding: '14px 18px',
              textAlign: 'left',
              minWidth: '180px',
            }}
          >
            <p style={{ fontWeight: 700, margin: '0 0 8px' }}>🏆 Top 3</p>
            {leaderboard.length > 0 ? (
              leaderboard.map((entry, i) => (
                <p key={i} style={{ margin: '4px 0' }}>
                  {i + 1}. {entry.name} — {entry.score}
                </p>
              ))
            ) : (
              <p style={{ margin: 0 }}>No scores yet</p>
            )}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: '150px',marginLeft:'55px'}}>
            <button
              onClick={handleRestart}
              style={{
                padding: '12px 30px',
                fontSize: '16px',
                fontWeight: 700,
                cursor: 'pointer',
                borderRadius: '999px',
                border: 'none',
                background: '#fff',
                color: '#1a1a1a',
              }}
            >
              Play Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
