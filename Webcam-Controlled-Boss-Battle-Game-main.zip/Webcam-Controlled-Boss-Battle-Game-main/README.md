# Webcam-Controlled-Boss-Battle-Game
Developed a webcam-controlled Souls-like boss battle using JavaScript, MediaPipe, and HTML5 Canvas, featuring real-time hand tracking, gesture-based attacks, hand-movement dodging, multi-phase boss AI, and interactive combat mechanics.
