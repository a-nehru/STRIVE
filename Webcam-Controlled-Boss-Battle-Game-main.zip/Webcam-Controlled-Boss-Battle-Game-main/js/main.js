const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const bossHealthBar = document.getElementById("boss-health");
const playerHealthBar = document.getElementById("player-health");
const staminaBar = document.getElementById("player-stamina");

const endScreen =
    document.getElementById("end-screen");

const endTitle =
    document.getElementById("end-title");

const restartButton =
    document.getElementById("restart-button");

const message = document.getElementById("message");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

/* =========================================
GAME
========================================= */

const game = {

running: true,
victory: false,
gameOver: false,

keys: {},

cameraShake: 0,

hitStop: 0,

time: 0

};

/* =========================================
PLAYER
========================================= */

const player = {

x: canvas.width / 2 - 180,
y: canvas.height / 2,

radius: 25,

speed: 4,

health: 100,
maxHealth: 100,

stamina: 100,
maxStamina: 100,

attackCooldown: 0,
attackTimer: 0,

dodgeCooldown: 0,
dodgeTimer: 0,

attacking: false,
dodging: false,
blocking: false,

attackType: "LIGHT",

attackHit: false,

direction: 1

};

/* =========================================
BOSS
========================================= */

const boss = {

x: canvas.width / 2 + 180,
y: canvas.height / 2,

radius: 45,

health: 1000,
maxHealth: 1000,

speed: 1.3,

phase: 1,

attacking: false,

attackTimer: 0,

attackCooldown: 80,

attackNumber: 0,

attackWarning: 0,

attackRange: 140,

hitFlash: 0,

stagger: 0

};

/* =========================================
PARTICLES
========================================= */

const particles = [];

function createParticles(x, y, amount = 15) {

for (let i = 0; i < amount; i++) {

    particles.push({

        x,
        y,

        vx: (Math.random() - 0.5) * 9,

        vy: (Math.random() - 0.5) * 9,

        life: 25 + Math.random() * 25,

        maxLife: 50,

        size: 2 + Math.random() * 4

    });

}

}

function updateParticles() {

for (let i = particles.length - 1; i >= 0; i--) {

    const p = particles[i];

    p.x += p.vx;
    p.y += p.vy;

    p.vx *= 0.94;
    p.vy *= 0.94;

    p.life--;

    if (p.life <= 0) {

        particles.splice(i, 1);

    }

}

}

function drawParticles() {

for (const p of particles) {

    ctx.globalAlpha = p.life / p.maxLife;

    ctx.fillStyle = "#ffffff";

    ctx.beginPath();

    ctx.arc(
        p.x,
        p.y,
        p.size,
        0,
        Math.PI * 2
    );

    ctx.fill();

}

ctx.globalAlpha = 1;

}

/* =========================================
KEYBOARD
========================================= */

window.addEventListener("keydown", event => {

game.keys[event.key.toLowerCase()] = true;


if (
    event.key === " " ||
    event.key === "Spacebar"
) {

    attack();

}


if (
    event.key.toLowerCase() === "shift"
) {

    dodge();

}


if (
    event.key.toLowerCase() === "e"
) {

    heavyAttack();

}


if (
    event.key.toLowerCase() === "q"
) {

    block();

}

});

window.addEventListener("keyup", event => {

game.keys[event.key.toLowerCase()] = false;


if (
    event.key.toLowerCase() === "q"
) {

    stopBlock();

}

});

/* =========================================
LIGHT ATTACK
========================================= */

function attack() {

if (!game.running)
    return;

if (player.attackCooldown > 0)
    return;

if (player.stamina < 15)
    return;

if (player.blocking)
    return;


player.stamina -= 15;

player.attacking = true;

player.attackType = "LIGHT";

player.attackTimer = 20;

player.attackCooldown = 25;

player.attackHit = false;

}

/* =========================================
HEAVY ATTACK
========================================= */

function heavyAttack() {

if (!game.running)
    return;

if (player.attackCooldown > 0)
    return;

if (player.stamina < 30)
    return;

if (player.blocking)
    return;


player.stamina -= 30;

player.attacking = true;

player.attackType = "HEAVY";

player.attackTimer = 32;

player.attackCooldown = 45;

player.attackHit = false;

}

/* =========================================
PLAYER ATTACK HIT WINDOW
========================================= */

function checkPlayerAttackHit() {

if (!player.attacking)
    return;

if (player.attackHit)
    return;


const maxTimer =
    player.attackType === "HEAVY"
        ? 32
        : 20;


const progress =
    1 -
    player.attackTimer / maxTimer;


/*
   Damage happens near the middle
   of the sword swing.
*/

if (
    progress < 0.35 ||
    progress > 0.75
) {

    return;

}


const distance = Math.hypot(

    player.x - boss.x,

    player.y - boss.y

);


const range =
    player.attackType === "HEAVY"
        ? 155
        : 130;


if (distance <= range) {

    const damage =
        player.attackType === "HEAVY"
            ? 100
            : 50;


    boss.health -= damage;

    boss.hitFlash = 8;

    boss.stagger =
        player.attackType === "HEAVY"
            ? 15
            : 8;


    game.cameraShake =
        player.attackType === "HEAVY"
            ? 16
            : 9;


    game.hitStop = 5;


    createParticles(
        boss.x,
        boss.y,
        player.attackType === "HEAVY"
            ? 30
            : 18
    );


    player.attackHit = true;


    updateUI();


    if (boss.health <= 0) {

        boss.health = 0;

        victory();

    }

}

}

/* =========================================
DODGE
========================================= */

function dodge() {

if (!game.running)
    return;

if (player.dodgeCooldown > 0)
    return;

if (player.stamina < 25)
    return;

if (player.blocking)
    return;


console.log("PLAYER DODGE");


player.stamina -= 25;

player.dodging = true;

/*
   Longer invincibility window
*/

player.dodgeTimer = 28;

player.dodgeCooldown = 35;


/*
   Strong dash
*/

const dodgeDistance = 180;

player.x +=
    player.direction *
    dodgeDistance;


/*
   Keep inside arena
*/

player.x = Math.max(
    60,
    Math.min(
        canvas.width - 60,
        player.x
    )
);


/*
   Dodge particles
*/

createParticles(
    player.x,
    player.y,
    25
);


/*
   Screen effect
*/

game.cameraShake = 5;

}

/* =========================================
BLOCK
========================================= */

function block() {

if (!game.running)
    return;

if (player.stamina <= 0)
    return;

player.blocking = true;

}

/* =========================================
STOP BLOCK
========================================= */

function stopBlock() {

player.blocking = false;

}

/* =========================================
PLAYER UPDATE
========================================= */

function updatePlayer() {

if (!game.running)
    return;


/* Movement */

if (
    game.keys["a"] ||
    game.keys["arrowleft"]
) {

    player.x -= player.speed;

    player.direction = -1;

}


if (
    game.keys["d"] ||
    game.keys["arrowright"]
) {

    player.x += player.speed;

    player.direction = 1;

}


if (
    game.keys["w"] ||
    game.keys["arrowup"]
) {

    player.y -= player.speed;

}


if (
    game.keys["s"] ||
    game.keys["arrowdown"]
) {

    player.y += player.speed;

}


/* Boundaries */

player.x = Math.max(
    60,
    Math.min(
        canvas.width - 60,
        player.x
    )
);


player.y = Math.max(
    150,
    Math.min(
        canvas.height - 80,
        player.y
    )
);


/* Cooldowns */

if (player.attackCooldown > 0)
    player.attackCooldown--;

if (player.dodgeCooldown > 0)
    player.dodgeCooldown--;


/* Attack */

if (player.attackTimer > 0) {

    player.attackTimer--;

    checkPlayerAttackHit();

}
else {

    player.attacking = false;

}


/* Dodge */

if (player.dodgeTimer > 0) {

    player.dodgeTimer--;

}
else {

    player.dodging = false;

}


/* Block */

if (player.blocking) {

    player.stamina -= 0.08;


    if (player.stamina <= 0) {

        player.stamina = 0;

        player.blocking = false;

    }

}


/* Stamina */

if (
    !player.attacking &&
    !player.dodging &&
    !player.blocking
) {

    player.stamina += 0.4;


    if (
        player.stamina >
        player.maxStamina
    ) {

        player.stamina =
            player.maxStamina;

    }

}

}

/* =========================================
BOSS PHASE
========================================= */

function updateBossPhase() {

if (
    boss.health <= 600 &&
    boss.health > 300
) {

    if (boss.phase !== 2) {

        boss.phase = 2;

        boss.speed = 1.8;

        createParticles(
            boss.x,
            boss.y,
            35
        );

    }

}


if (boss.health <= 300) {

    if (boss.phase !== 3) {

        boss.phase = 3;

        boss.speed = 2.5;

        createParticles(
            boss.x,
            boss.y,
            50
        );

    }

}

}

/* =========================================
BOSS AI
========================================= */

function updateBoss() {

if (!game.running)
    return;


updateBossPhase();


if (boss.hitFlash > 0)
    boss.hitFlash--;


if (boss.stagger > 0) {

    boss.stagger--;

    return;

}


const dx =
    player.x - boss.x;

const dy =
    player.y - boss.y;

const distance =
    Math.hypot(dx, dy);


/* Move toward player */

if (
    distance > 105 &&
    !boss.attacking
) {

    boss.x +=
        (dx / distance) *
        boss.speed;

    boss.y +=
        (dy / distance) *
        boss.speed;

}


/* Cooldown */

if (boss.attackCooldown > 0) {

    boss.attackCooldown--;

}


/*
   Start boss attack
*/

if (
    distance < 170 &&
    boss.attackCooldown <= 0 &&
    !boss.attacking
) {

    startBossAttack();

}


/*
   Active attack
*/

if (boss.attacking) {

    boss.attackTimer--;


    if (boss.attackTimer <= 0) {

        finishBossAttack();

    }

}

}

/* =========================================
START BOSS ATTACK
========================================= */

function startBossAttack() {

boss.attacking = true;

boss.attackWarning = 30;


/*
   Faster attacks in later phases
*/

boss.attackTimer =

    boss.phase === 1
        ? 45

        : boss.phase === 2
            ? 35

            : 27;


boss.attackNumber++;


/*
   Three attack styles
*/

if (boss.attackNumber % 3 === 0) {

    boss.attackRange = 175;

}
else {

    boss.attackRange = 140;

}

}

/* =========================================
FINISH BOSS ATTACK
========================================= */

function finishBossAttack() {

boss.attacking = false;

boss.attackWarning = 0;


damagePlayer();


/*
   Combo cooldown
*/

boss.attackCooldown =

    boss.phase === 1
        ? 75

        : boss.phase === 2
            ? 50

            : 32;

}

/* =========================================
DAMAGE PLAYER
========================================= */

function damagePlayer() {

const distance = Math.hypot(

    player.x - boss.x,

    player.y - boss.y

);


if (
    distance >
    boss.attackRange
) {

    return;

}


/*
   Perfect dodge
*/

if (player.dodging) {

    game.cameraShake = 5;

    createParticles(
        player.x,
        player.y,
        25
    );

    return;

}


/*
   Block
*/

if (player.blocking) {

    const staminaDamage =
        boss.phase === 3
            ? 30
            : 20;


    player.stamina -= staminaDamage;


    game.cameraShake = 7;


    createParticles(
        player.x,
        player.y,
        15
    );


    if (player.stamina <= 0) {

        player.stamina = 0;

        player.blocking = false;

    }


    updateUI();

    return;

}


/*
   Normal damage
*/

let damage = 10;


if (boss.phase === 2)
    damage = 15;

if (boss.phase === 3)
    damage = 20;


player.health -= damage;


game.cameraShake = 15;


createParticles(
    player.x,
    player.y,
    20
);


updateUI();


if (player.health <= 0) {

    player.health = 0;

    defeat();

}

}

/* =========================================
UI
========================================= */

function updateUI() {

bossHealthBar.style.width =

    `${(boss.health / boss.maxHealth) * 100}%`;


playerHealthBar.style.width =

    `${(player.health / player.maxHealth) * 100}%`;


staminaBar.style.width =

    `${(player.stamina / player.maxStamina) * 100}%`;

}

/* =========================================
ARENA
========================================= */

function drawArena() {

ctx.fillStyle = "#080808";

ctx.fillRect(
    0,
    0,
    canvas.width,
    canvas.height
);


/*
   Arena floor
*/

ctx.fillStyle = "#181818";


ctx.beginPath();

ctx.ellipse(

    canvas.width / 2,

    canvas.height / 2 + 40,

    canvas.width * 0.42,

    canvas.height * 0.35,

    0,

    0,

    Math.PI * 2

);

ctx.fill();


/*
   Floor lines
*/

ctx.strokeStyle = "#292929";

ctx.lineWidth = 2;


for (
    let i = 0;
    i < 12;
    i++
) {

    ctx.beginPath();


    ctx.moveTo(

        canvas.width / 2,

        canvas.height / 2 + 40

    );


    const angle =
        (Math.PI * 2 / 12) * i;


    ctx.lineTo(

        canvas.width / 2 +
        Math.cos(angle) *
        canvas.width * 0.42,

        canvas.height / 2 + 40 +
        Math.sin(angle) *
        canvas.height * 0.35

    );


    ctx.stroke();

}


/*
   Center ring
*/

ctx.strokeStyle = "#333";

ctx.lineWidth = 3;


ctx.beginPath();

ctx.ellipse(

    canvas.width / 2,

    canvas.height / 2 + 40,

    canvas.width * 0.20,

    canvas.height * 0.15,

    0,

    0,

    Math.PI * 2

);

ctx.stroke();

}

/* =========================================
PLAYER DRAW
========================================= */

function drawPlayer() {

ctx.save();


ctx.translate(
    player.x,
    player.y
);


/*
   Dodge
*/

if (player.dodging) {

    ctx.globalAlpha = 0.4;

}


/*
   Block shield
*/

if (player.blocking) {

    ctx.strokeStyle = "#38aaff";

    ctx.lineWidth = 6;

    ctx.shadowBlur = 20;

    ctx.shadowColor = "#38aaff";


    ctx.beginPath();

    ctx.arc(
        0,
        0,
        52,
        0,
        Math.PI * 2
    );

    ctx.stroke();


    ctx.shadowBlur = 0;

}


/*
   Body
*/

ctx.fillStyle = "#c7c7c7";


ctx.beginPath();

ctx.arc(
    0,
    0,
    player.radius,
    0,
    Math.PI * 2
);

ctx.fill();


/*
   Head
*/

ctx.fillStyle = "#888";


ctx.beginPath();

ctx.arc(
    0,
    -28,
    12,
    0,
    Math.PI * 2
);

ctx.fill();


/*
   Sword
*/

ctx.strokeStyle =
    player.attacking
        ? "#ffffff"
        : "#dddddd";


ctx.lineWidth =
    player.attackType === "HEAVY"
        ? 11
        : 7;


ctx.shadowBlur =
    player.attacking
        ? 15
        : 0;


ctx.shadowColor = "#ffffff";


ctx.beginPath();


if (player.attacking) {

    const maxTimer =
        player.attackType === "HEAVY"
            ? 32
            : 20;


    const progress =
        1 -
        player.attackTimer /
        maxTimer;


    const angle =
        -1.5 +
        progress * 3;


    ctx.moveTo(
        0,
        0
    );


    ctx.lineTo(

        Math.cos(angle) *
        95 *
        player.direction,

        Math.sin(angle) *
        95

    );

}
else {

    ctx.moveTo(
        player.direction * 10,
        0
    );


    ctx.lineTo(
        player.direction * 55,
        20
    );

}


ctx.stroke();


/*
   Sword trail
*/

if (player.attacking) {

    ctx.globalAlpha = 0.25;

    ctx.lineWidth = 18;


    ctx.beginPath();

    ctx.arc(

        0,
        0,

        75,

        player.direction === 1
            ? -1.4
            : Math.PI - 1.4,

        player.direction === 1
            ? 1.2
            : Math.PI + 1.2

    );

    ctx.stroke();

}


ctx.restore();

}

/* =========================================
BOSS DRAW
========================================= */

function drawBoss() {

ctx.save();


ctx.translate(
    boss.x,
    boss.y
);


/*
   Phase 3 aura
*/

if (boss.phase === 3) {

    ctx.shadowBlur = 40;

    ctx.shadowColor = "#ff0000";

}


/*
   Hit flash
*/

if (boss.hitFlash > 0) {

    ctx.fillStyle = "#ffffff";

}
else {

    ctx.fillStyle =

        boss.phase === 3
            ? "#650000"

            : boss.phase === 2
                ? "#333333"

                : "#3b3b3b";

}


/*
   Body
*/

ctx.beginPath();

ctx.arc(
    0,
    0,
    boss.radius,
    0,
    Math.PI * 2
);

ctx.fill();


/*
   Head
*/

ctx.fillStyle = "#111";


ctx.beginPath();

ctx.arc(
    0,
    -50,
    20,
    0,
    Math.PI * 2
);

ctx.fill();


/*
   Eyes
*/

ctx.fillStyle =
    boss.phase === 3
        ? "#ff0000"
        : "#ff4444";


ctx.beginPath();

ctx.arc(
    -7,
    -52,
    3,
    0,
    Math.PI * 2
);

ctx.arc(
    7,
    -52,
    3,
    0,
    Math.PI * 2
);

ctx.fill();


/*
   Boss attack telegraph
*/

if (boss.attacking) {

    const alpha =
        boss.attackTimer < 15
            ? 0.7
            : 0.25;


    ctx.globalAlpha = alpha;

    ctx.strokeStyle = "#ff0000";

    ctx.lineWidth = 7;


    ctx.beginPath();

    ctx.arc(

        0,
        0,

        boss.attackRange,

        0,

        Math.PI * 2

    );

    ctx.stroke();


    /*
       Inner warning
    */

    ctx.globalAlpha = 0.4;

    ctx.fillStyle = "#ff0000";


    ctx.beginPath();

    ctx.arc(
        0,
        0,
        65,
        0,
        Math.PI * 2
    );

    ctx.fill();

}


/*
   Boss sword
*/

ctx.globalAlpha = 1;

ctx.strokeStyle =

    boss.attacking
        ? "#ff2222"
        : "#aaaaaa";


ctx.lineWidth =

    boss.attacking
        ? 14
        : 8;


ctx.shadowBlur =
    boss.attacking
        ? 18
        : 0;


ctx.shadowColor = "#ff2222";


ctx.beginPath();

ctx.moveTo(
    -10,
    0
);

ctx.lineTo(
    -85,
    40
);

ctx.stroke();


ctx.restore();

}

/* =========================================
VICTORY
========================================= */

function victory() {

    game.running = false;

    game.victory = true;

    endTitle.textContent = "VICTORY";

    endScreen.style.display = "flex";

}

/* =========================================
DEFEAT
========================================= */

function defeat() {

    game.running = false;

    game.gameOver = true;

    endTitle.textContent = "YOU DIED";

    endScreen.style.display = "flex";

}


restartButton.addEventListener("click", () => {

    location.reload();

});

/* =========================================
RESIZE
========================================= */

window.addEventListener("resize", () => {

canvas.width = window.innerWidth;

canvas.height = window.innerHeight;

});

/* =========================================
GAME LOOP
========================================= */

function gameLoop() {

game.time++;


if (game.hitStop > 0) {

    game.hitStop--;

}
else {

    updatePlayer();

    updateBoss();

}


/*
   Camera shake
*/

let shakeX = 0;
let shakeY = 0;


if (game.cameraShake > 0) {

    shakeX =
        (Math.random() - 0.5) *
        game.cameraShake;

    shakeY =
        (Math.random() - 0.5) *
        game.cameraShake;

    game.cameraShake *= 0.9;

}


ctx.save();


ctx.translate(
    shakeX,
    shakeY
);


drawArena();

drawBoss();

drawPlayer();

updateParticles();

drawParticles();


ctx.restore();


updateUI();


requestAnimationFrame(gameLoop);

}

/* =========================================
START
========================================= */

updateUI();

gameLoop();