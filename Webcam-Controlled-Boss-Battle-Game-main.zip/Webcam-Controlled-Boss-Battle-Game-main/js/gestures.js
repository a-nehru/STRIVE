const webcam = document.getElementById("webcam");
const gestureText = document.getElementById("gesture");
const handCanvas = document.getElementById("handCanvas");

const handCtx = handCanvas.getContext("2d");

/* =========================================
STATE
========================================= */

let currentGesture = "NO HAND";
let lastGesture = "NONE";

let previousX = null;
let previousY = null;

let smoothX = null;
let smoothY = null;

let lostFrames = 0;

let movementCooldown = 0;

const SWIPE_THRESHOLD = 0.018;

const SMOOTHING = 0.65;

/* =========================================
MEDIAPIPE HANDS
========================================= */

const hands = new Hands({

locateFile: (file) => {

    return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`;

}

});

hands.setOptions({

maxNumHands: 1,

/*
   Better tracking quality
*/

modelComplexity: 1,

/*
   Slightly easier to detect hand
*/

minDetectionConfidence: 0.45,

minTrackingConfidence: 0.45,

selfieMode: true

});

/* =========================================
RESULTS
========================================= */

hands.onResults((results) => {

/*
   Camera resolution
*/

handCanvas.width =
    webcam.videoWidth || 480;

handCanvas.height =
    webcam.videoHeight || 360;


/*
   Clear skeleton
*/

handCtx.clearRect(
    0,
    0,
    handCanvas.width,
    handCanvas.height
);


/*
   No hand
*/

if (
    !results.multiHandLandmarks ||
    results.multiHandLandmarks.length === 0
) {

    lostFrames++;


    /*
       Don't immediately reset movement.

       MediaPipe can lose the hand for a
       couple frames during fast movement.
    */

    if (lostFrames < 8) {

        return;

    }


    currentGesture = "NO HAND";


    if (gestureText) {

        gestureText.textContent =
            "NO HAND";

    }


    /*
       Only reset after the hand has really
       disappeared.
    */

    previousX = null;
    previousY = null;

    smoothX = null;
    smoothY = null;

    return;

}


/*
   Hand found again
*/

lostFrames = 0;


const landmarks =
    results.multiHandLandmarks[0];


/* =====================================
   GREEN SKELETON
===================================== */

drawConnectors(

    handCtx,

    landmarks,

    HAND_CONNECTIONS,

    {

        color: "#00ff66",

        lineWidth: 3

    }

);


drawLandmarks(

    handCtx,

    landmarks,

    {

        color: "#00ff66",

        lineWidth: 2,

        radius: 5

    }

);


/* =====================================
   GESTURES
===================================== */

detectGesture(landmarks);


/* =====================================
   MOVEMENT
===================================== */

detectHandMovement(landmarks);

});

/* =========================================
GESTURE DETECTION
========================================= */

function detectGesture(landmarks) {

const indexOpen =
    landmarks[8].y <
    landmarks[6].y;


const middleOpen =
    landmarks[12].y <
    landmarks[10].y;


const ringOpen =
    landmarks[16].y <
    landmarks[14].y;


const pinkyOpen =
    landmarks[20].y <
    landmarks[18].y;


let detected = "NONE";


/*
   OPEN PALM
*/

if (
    indexOpen &&
    middleOpen &&
    ringOpen &&
    pinkyOpen
) {

    detected = "BLOCK";

}


/*
   ONE FINGER
*/

else if (
    indexOpen &&
    !middleOpen &&
    !ringOpen &&
    !pinkyOpen
) {

    detected = "HEAVY";

}


/*
   FIST
*/

else if (
    !indexOpen &&
    !middleOpen &&
    !ringOpen &&
    !pinkyOpen
) {

    detected = "ATTACK";

}


currentGesture = detected;


if (gestureText) {

    gestureText.textContent =
        detected;

}


/*
   Game actions
*/

if (
    typeof game === "undefined" ||
    !game.running
) {

    return;

}


if (detected === "ATTACK") {

    attack();

}


else if (detected === "HEAVY") {

    heavyAttack();

}


else if (detected === "BLOCK") {

    block();

}


else {

    stopBlock();

}


lastGesture = detected;

}

/* =========================================
HAND MOVEMENT
========================================= */

function detectHandMovement(landmarks) {

const wrist =
    landmarks[0];


const indexBase =
    landmarks[5];


const pinkyBase =
    landmarks[17];


/*
   Palm center
*/

const rawX =
    (
        wrist.x +
        indexBase.x +
        pinkyBase.x
    ) / 3;


const rawY =
    (
        wrist.y +
        indexBase.y +
        pinkyBase.y
    ) / 3;


/* =====================================
   SMOOTH POSITION
===================================== */

if (
    smoothX === null ||
    smoothY === null
) {

    smoothX = rawX;
    smoothY = rawY;

}
else {

    smoothX =
        smoothX * SMOOTHING +
        rawX * (1 - SMOOTHING);


    smoothY =
        smoothY * SMOOTHING +
        rawY * (1 - SMOOTHING);

}


/*
   First position
*/

if (
    previousX === null ||
    previousY === null
) {

    previousX = smoothX;
    previousY = smoothY;

    return;

}


/*
   Movement
*/

const movementX =
    smoothX - previousX;


const movementY =
    smoothY - previousY;


/*
   Update position
*/

previousX = smoothX;
previousY = smoothY;


/*
   Cooldown
*/

if (movementCooldown > 0) {

    movementCooldown--;

    return;

}


/*
   Movement strength
*/

const horizontal =
    Math.abs(movementX);


const vertical =
    Math.abs(movementY);


/*
   Ignore tiny movement
*/

if (
    horizontal < SWIPE_THRESHOLD &&
    vertical < SWIPE_THRESHOLD
) {

    return;

}


/*
   Game check
*/

if (
    typeof game === "undefined" ||
    !game.running
) {

    return;

}


/* =====================================
   HORIZONTAL
===================================== */

if (horizontal > vertical) {

    if (movementX > 0) {

        movementDodge("RIGHT");

    }
    else {

        movementDodge("LEFT");

    }

}


/* =====================================
   VERTICAL
===================================== */

else {

    if (movementY > 0) {

        movementDodge("DOWN");

    }
    else {

        movementDodge("UP");

    }

}

}

/* =========================================
MOVEMENT DODGE
========================================= */

function movementDodge(direction) {

if (
    typeof player === "undefined"
) {

    return;

}


if (
    player.dodgeCooldown > 0
) {

    return;

}


if (
    player.stamina < 25
) {

    return;

}


if (
    player.blocking
) {

    return;

}


console.log(
    "HAND MOVEMENT DODGE:",
    direction
);


/*
   Consume stamina
*/

player.stamina -= 25;


/*
   Invincibility
*/

player.dodging = true;

player.dodgeTimer = 28;

player.dodgeCooldown = 35;


/*
   Movement amount
*/

const distance = 180;


switch (direction) {

    case "LEFT":

        player.x -= distance;

        break;


    case "RIGHT":

        player.x += distance;

        break;


    case "UP":

        player.y -= distance;

        break;


    case "DOWN":

        player.y += distance;

        break;

}


/*
   Arena limits
*/

player.x = Math.max(
    60,
    Math.min(
        canvas.width - 60,
        player.x
    )
);


player.y = Math.max(
    150,
    Math.min(
        canvas.height - 80,
        player.y
    )
);


/*
   Particles
*/

if (
    typeof createParticles === "function"
) {

    createParticles(
        player.x,
        player.y,
        25
    );

}


/*
   Camera shake
*/

game.cameraShake = 5;


/*
   Dodge cooldown
*/

movementCooldown = 15;

}

/* =========================================
CAMERA
========================================= */

const camera = new Camera(

webcam,

{

    onFrame: async () => {

        await hands.send({

            image: webcam

        });

    },


    width: 480,

    height: 360

}

);

camera.start();